package com.example.dsrpt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
