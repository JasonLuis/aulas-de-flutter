import 'package:flutter/material.dart';

//a letra 'c' é de constante
const cPrimaryColor = Color(0xFF422F89);
const cTextoCor = Color(0xFF3C4046);
const cBackgroundColor = Color(0xFFF9F8FD);

const double cPadding = 20.0;
