# Flutter Facebok Authentication

A basic Flutter project with Facebook login support. 

Package used: [flutter_facebook_login](https://github.com/roughike/flutter_facebook_login/)
<br>Medium tutorial: [Flutter Facebook Login](https://medium.com/@rohantaneja/flutter-facebook-login-77fcd187242)

# Note
Cloning this project and trying to run it won't work because this project on the Firebase console doesn't have your SHA-1 key

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
