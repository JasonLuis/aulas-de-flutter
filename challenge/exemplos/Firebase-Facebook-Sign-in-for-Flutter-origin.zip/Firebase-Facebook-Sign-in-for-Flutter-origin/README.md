# Flutter Firebase Facebook Sign-in

This is the code for the following videos.

[![Facebook_sign_in_flutter](http://img.youtube.com/vi/DCsG3W1dFkI/0.jpg)](http://www.youtube.com/watch?v=DCsG3W1dFkI "Facebook Flutter Authentication for Flutter")


[![Facebook_sign_in_flutter](http://img.youtube.com/vi/RiE-g455j9s/0.jpg)](http://www.youtube.com/watch?v=RiE-g455j9s "Facebook Flutter Authentication for Flutter")
