import 'package:curso/screens/widget/curso_listview.dart';
import 'package:curso/screens/widget/curso_listview_loading.dart';
import 'package:curso/stores/curso_screen_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter_mobx/flutter_mobx.dart';

class CursosScreen extends StatefulWidget {
  @override
  _CursosScreenState createState() => _CursosScreenState();
}

class _CursosScreenState extends State<CursosScreen> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  final CursoScreenStore cursoScreenStore = CursoScreenStore();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(64, 75, 96, .9),
        title: TextField(
          decoration: InputDecoration(
            hintText: "Digite o nome do curso",
          ),
          onChanged: cursoScreenStore.setFilter,
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Text('${cursoScreenStore.quantidade}'),
          )
        ],
      ),
      body: Observer(
        builder: (ctx) {
          if (cursoScreenStore.isLoading) {
            return CursoListViewLoading();
          } else {
            return CursoListView(
              cursos: cursoScreenStore.filtered,
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Color.fromRGBO(64, 75, 96, .9),
        child: Icon(Icons.cached),
        onPressed: () async {
          print('floating');
          cursoScreenStore.findAllCourses();
        },
      ),
    );
  }
}
