package com.example.nac_mobx

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
