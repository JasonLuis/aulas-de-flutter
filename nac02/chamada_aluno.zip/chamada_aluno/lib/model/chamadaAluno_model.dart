class ChamadaAluno {
  int id;
  String data;
  int presenca;
  
}