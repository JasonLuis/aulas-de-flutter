package com.example.lista_cursos

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
