

class CursoModel {
  int id;
  String nome;
  String nivel;
  double percentualConclusao;
  int preco;
  String conteudo;

  CursoModel({
    this.id,
    this.nome,
    this.nivel,
    this.percentualConclusao,
    this.preco,
    this.conteudo,
  });
}